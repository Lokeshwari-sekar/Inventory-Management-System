package com.example.demo.error;
/**
 * This product not found exception class is 
 * used to display the product operation error message in the output screen
 * 
 */
public class ProductNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public ProductNotFoundException(String s)
	{
		super(s);
	}
}

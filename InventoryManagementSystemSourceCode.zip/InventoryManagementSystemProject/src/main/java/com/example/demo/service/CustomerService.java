package com.example.demo.service;
import java.util.List;
import com.example.demo.entity.Customer;
import com.example.demo.error.CustomerNotFoundException;
/**
 * This customer interface is used for create the abstract methods
 *
 */

public interface CustomerService {

    //select customers
    List<Customer> selectAllCustomers();
    // select customer using id
	Customer getCustomers(int id) throws CustomerNotFoundException;
    // delete customer using id
	void deleteCustomerById(int cid) throws CustomerNotFoundException;
    // update customer using id
	Customer updateCustomerById(int id, Customer customer) throws CustomerNotFoundException;

}

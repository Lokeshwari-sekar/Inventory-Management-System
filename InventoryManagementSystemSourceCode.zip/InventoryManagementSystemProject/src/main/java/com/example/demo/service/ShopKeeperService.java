package com.example.demo.service;
import java.util.List;
import com.example.demo.entity.ShopKeeper;
import com.example.demo.error.ProductNotFoundException;
/**
 * This service interface is used for create the abstract methods
 *
 */
public interface ShopKeeperService {
    //insert product
	ShopKeeper insertProduct(ShopKeeper shopkeeper);
    //select product using id
    ShopKeeper selectProductById(int pid) throws ProductNotFoundException;
    //delete product using id
	void deleteProductById(int pid) throws ProductNotFoundException;
    //update product using id
	ShopKeeper updateProductById(int id, ShopKeeper shopkeeper) throws ProductNotFoundException;
	//select all products
	List<ShopKeeper> selectAllProduct();
    //select product using name
	ShopKeeper findByproductName(String pname);
    //select product using type
	ShopKeeper findByproductType(String ptype);
	//select product using brand
	ShopKeeper findByproductBrand(String pbrand);
	//select product using quantity
	ShopKeeper findByproductQuantity(int pquantity);
	//select product using price
	ShopKeeper findByproductPrice(double pprice);





	


	





	


	
	
	

	
	

	

	

	

	

}

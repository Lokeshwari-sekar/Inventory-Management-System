package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.ShopKeeper;
/**
 * The shopkeeper repository interface is extending the JpaRepository for
 * use the predefined methods.
 * 
 * This is the entry point for custom methods
 */
@Repository
public interface ShopKeeperRepository extends JpaRepository<ShopKeeper, Integer> {

	//select product using product name
	ShopKeeper findByproductName(String pname);
	//select product using product type
	ShopKeeper findByproductType(String ptype);
	//select product using product brand
	ShopKeeper findByproductBrand(String pbrand);
	//select product using product quantity
	ShopKeeper findByproductQuantity(int pquantity);
	//select product using product price
	ShopKeeper findByproductPrice(double pprice);

	



	

	
	
	



	

	

}

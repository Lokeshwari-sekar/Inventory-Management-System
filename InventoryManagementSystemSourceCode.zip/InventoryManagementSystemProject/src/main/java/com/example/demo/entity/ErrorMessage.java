package com.example.demo.entity;

import org.springframework.http.HttpStatus;
/**
 * This class is mainly used for dispaly the message 
 * when the error occurs the http status and message is displayed in the output screen
 * 
 * http status: What is the status of the execution that is displayed here
 * Message: What message we want that will be displayed here
 *
 */
public class ErrorMessage {
       private HttpStatus status;
	   private String message;
	public ErrorMessage() {
		super();
	}
	public ErrorMessage(HttpStatus status, String message) {
		super();
		this.status = status;
		this.message = message;
	}
	public HttpStatus getStatus() {
		return status;
	}
	public void setStatus(HttpStatus status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "ErrorMessage [status=" + status + ", message=" + message + "]";
	}


}
